package com.example.applibras;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class BemVindoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bem_vindo);
    }

    public void novoscursos(View view) {

    }

    public void meuscursos(View view) {

    }

    public void testes(View view) {

    }

    public void duvidas(View view) {

    }

    public void planos(View view) {

    }
}
